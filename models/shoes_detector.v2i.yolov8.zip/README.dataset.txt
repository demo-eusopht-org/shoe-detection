# shoes_detector > 2024-09-06 1:18pm
https://universe.roboflow.com/mjtech/shoes_detector

Provided by a Roboflow user
License: CC BY 4.0

